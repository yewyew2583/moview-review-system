<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<button  class="btn btn-primary" data-toggle="modal" data-target="#editMovieModal"><span class="glyphicon glyphicon-edit"></span> Edit</button>
				<button  class="btn btn-danger"><span class="glyphicon glyphicon-remove"></span> Delete</button>
			</div>
	   	</div>
	   	<br><br>
			<div class="card">
				<div class="row">
					<div class="col-md-4">
						<div class="card-img" style="width:350px;height:350px;">
					    	<img class="card-img-top card-img" style="width:100%;height:100%;" src="movieImageUpload/<?php echo e($movie_detail-> image); ?>">
						</div>
					 </div>
					<div class="col-md-8">
						<div class="card-block">
							<h3 class="card-title"><b><?php echo e($movie_detail-> title); ?></b></h4>
							<p><b>Synopsis:</b></p>
							<p class="card-text"><?php echo e($movie_detail-> synopsis); ?></p>
							<p><b>Genre: </b><?php echo e($movie_detail-> genre); ?></p>
							<p><b>Year released: </b><?php echo e($movie_detail-> year); ?></p>
							<p>
								<b>Reviews: </b>
								<b><?php echo e($movie_detail-> rating); ?> <span class="glyphicon glyphicon-star"></span></b>
							</p>
						</div>
					</div>
				</div>
			</div>
			 <!--edit modal-->
              <div class="modal fade" id="editMovieModal" role="">
                <div class="modal-dialog">
                
                  <!-- Modal content-->
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" style="font-size:2.5em;">&times;</button>
                      <h4 class="modal-title">Edit Movie</h4>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                    <label for="fileToUpload">Select Movie Image to Upload:</label>
                                    <input type="file" class="btn btn-default" name="fileToUpload" id="fileToUpload">
                                    <br>
                                    <input type="submit" class="btn btn-warning" value="Upload Image" name="submit">
                            </div>
                            <div class="col-md-12"><hr></div>
                            <div class="col-md-4">
                                <label for="movieNameTxt">Movie Name:</label>
                                <input type="text" class="form-control" name="movieNameTxt" id="movieNameTxt">
                            </div>
                            <div class="col-md-4">
                                <label for="yearTxt">Year Released:</label>
                                <input type="text" class="form-control" name="yearTxt" id="yearTxt">
                            </div>
                            <div class="col-md-4">
                                <label for="selectGenre">Select Genre:</label>
                                <select class="btn btn-default" id="selectGenre" class="form-control">
                                    <option>ACTION</option>
                                    <option>COMEDY</option>
                                    <option>SCIENCE</option>
                                </select>
                            </div>
                            <div class="col-md-12">
                                <label for="synopsisTxt">Synopsis:</label>
                                <textarea type="text" class="form-control" name="synopsisTxt" id="synopsisTxt" style="resize:none;height:200px"></textarea> 
                            </div>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      <button type="button" class="btn btn-primary">Save Changes</button>
                    </div>
                  </div>
                </div>
              </div>
        </div>
        <!--edit modal ends-->
	</div><!--container-->
</body>
</html>