<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
    <h1 class="zz"></h1>
</body>
</html>
<script type="text/javascript">
var $member_type = localStorage.getItem('member_type');
var $username = localStorage.getItem('username');

$(document).ready(function(){
    if(localStorage.getItem('member_pk') != '' && localStorage.getItem('member_pk') != null){
        $(".login-register-href").hide();
        $.ajax({
            url: '<?php echo e(url("/listMovie")); ?>',
            success: function(result){
                $(".dropdown-toggle-username").html($username + "<span class='caret'></span>");
                $(".username-dropdown").show();
                if($member_type == 'ADMIN'){
                    $('.zz').html("hello im admin");
                    //admin diff thing
                }
                else{
                    listMovie();
                }
            },
            fail:function(){
                console.log("failed retrive movies data");
            }
        });
    }
    else{
        listMovie();
    }
});

function listMovie(){
        $.ajax({
            url: '<?php echo e(url("/listMovie")); ?>',
            success: function(result){
                //list movie
            },
            fail:function(){
                console.log("failed retrive movies data");
            }
        });
}
</script>
