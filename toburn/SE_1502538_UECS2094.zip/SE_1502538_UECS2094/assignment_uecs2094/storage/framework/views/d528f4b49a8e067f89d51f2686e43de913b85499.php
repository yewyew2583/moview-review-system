Error detected pls relogin!
//clear session storage and reload 