<!DOCTYPE html>
<html>
<head>
    <title></title>
<style type="text/css">
.hoverable-card:hover{
    box-shadow: 2px 2px 2px 4px #cccccc;
    cursor:pointer;
}

.hoverable-card{
    height:400px;
}

.card{
    height:300px;
}

.card-img{
    width:100%;
    height:100%;
}



</style>
</head>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                 <input type="text" class="form-control" id="searchTxt" name="searchTxt" placeholder="Enter Movie Name">
            </div>
            <div class="col-md-2">
                <select class="btn btn-default genre-select" id="genreTxt" style="width:100%;">
                  <option value="any" selected="selected">any(Filter By Genre)</option>
                  <option value="action">action</option>
                  <option value="comedy">comedy</option>
                  <option value="science">science</option>
                </select>
            </div>
            <div class="col-md-2">
                <select class="btn btn-default" id="yearTxt" style="width:100%;">
                  <option value="any" selected="selected">any(Filter By Year)</option>
                  <option value="action">2015</option>
                  <option value="comedy">2014</option>
                  <option value="science">2016</option>
                </select>
            </div>
            <div class="col-md-2">
                <button class="btn btn-primary"><span class="glyphicon glyphicon-search"></span> Search Movie</button>
            </div>
            <div class="col-md-2 pull-right">
                <button type="button" class="btn btn-success pull-right" id="btn-add-movie" data-toggle="modal" data-target="#addMovieModal"><span class="glyphicon glyphicon-plus"></span> Add Movie</button>
            </div>
        </div><br><br>
        <div class="row" id="row-to-append-movie">
            <!--<div class="col-md-3 hoverable-card" onclick="movieDetail(1)">
                <div class="card text-white bg-secondary mb-3">
                  <img class="card-img-top card-img" src="https://img00.deviantart.net/364f/i/2014/044/f/c/amazing_spider_man_3_wallpaper_by_webhead9707-d76cglu.png">
                  <div class="card-body">
                    <p class="card-text">
                        <p>Spiderman 3</p>
                        <p>Review: 
                            <span class="glyphicon glyphicon-star"></span>
                            <span class="glyphicon glyphicon-star"></span>
                            <span class="glyphicon glyphicon-star"></span>
                            <span class="glyphicon glyphicon-star"></span>
                            <span class="glyphicon glyphicon-star"></span>
                        </p>
                        <p>Genre: Comedy</p>
                    </p>
                  </div>
                </div>
            </div>-->
        </div>
            <!-- Modal -->

              <div class="modal fade" id="addMovieModal" role="">
                <div class="modal-dialog">
                <form action="<?php echo e(url('addMovie')); ?>" method="post" enctype="multipart/form-data">
                  <!-- Modal content-->
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" style="font-size:2.5em;">&times;</button>
                      <h4 class="modal-title">Add Movie</h4>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                    <label for="image">Select Movie Image to Upload:</label>
                                    <input type="file" class="btn btn-default image-file" name="image" id="image">
                                    <br>
                                    <!--<input type="submit" class="btn btn-warning" value="Upload Image" name="submit">-->
                                    <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token">
                            </div>
                            <div class="col-md-12"><hr></div>
                            <div class="col-md-4">
                                <label for="movieNameTxt">Movie Name:</label>
                                <input type="text" class="form-control" name="movieNameTxt" id="movieNameTxt">
                            </div>
                            <div class="col-md-4">
                                <label for="yearTxt">Year Released:</label>
                                <input type="text" class="form-control" name="yearTxt" id="yearTxt">
                            </div>
                            <div class="col-md-4">
                                <label for="selectGenre">Select Genre:</label>
                                <select class="btn btn-default" id="selectGenre" name="genreTxt" class="form-control">
                                    <option>ACTION</option>
                                    <option>COMEDY</option>
                                    <option>SCIENCE</option>
                                </select>
                            </div>
                            <div class="col-md-12">
                                <label for="synopsisTxt">Synopsis:</label>
                                <textarea type="text" class="form-control" name="synopsisTxt" id="synopsisTxt" style="resize:none;height:200px"></textarea> 
                            </div>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      <button type="button" class="btn btn-primary" name="submit" id="btn-confirm-add-movie">Add Movie</button>
                      <input type="submit" id="click-add-movie" style="display:none;">
                    </div>
                  </div>
                </div>
            </form>
            </div>
        </div>
</body>
</html>
<script type="text/javascript">
var $member_type = sessionStorage.getItem('member_type');

$(document).ready(function(){
    //initialize the modal form to be clicked later

    $('.dropdown-toggle').dropdown();
    $.ajax({
        url: "<?php echo e(url('listMovies')); ?>",
        success:function(result){
            console.log(result);
            var $movies = result;

            for(var i=0;i<$movies.length;i++){

                var $p_movie_name = document.createElement('p');
                var $p_review = document.createElement('p');
                var $p_genre = document.createElement('p');

                var $p_card_text = document.createElement('p');

                var $div_card_body = document.createElement('div');
                var $img_card = document.createElement('img');

                var $div_card = document.createElement('div');

                var $col_card = document.createElement('div');

                $p_card_text.className = 'card-text';
                $div_card_body.className = 'card-body';
                $img_card.className = 'card-img-top card-img';
                $div_card.className = 'card text-white bg-secondary mb-3';
                $col_card.className = 'col-md-3 hoverable-card';

                $p_movie_name.innerHTML = $movies[i].title;
                $p_review.innerHTML = 'Review: ';
                for(var j=0;j<$movies[i].rating;j++){
                    console.log($movies[i].rating);
                    var star = document.createElement('span');
                    star.className = 'glyphicon glyphicon-star';
                    $p_review.appendChild(star);
                }
                $p_genre.innerHTML = 'Genre: ' + $movies[i].genre;
                $img_card.src = 'movieImageUpload/' + $movies[i].image;

                $col_card.setAttribute("onclick", "movieDetail(" + i + ")");

                $p_card_text.appendChild($p_movie_name);
                $p_card_text.appendChild($p_review);
                $p_card_text.appendChild($p_genre);

                $div_card_body.appendChild($p_card_text);

                $div_card.appendChild($img_card);
                $div_card.appendChild($div_card_body);

                $col_card.appendChild($div_card);

                $row_to_append_movie = document.getElementById('row-to-append-movie');
                $row_to_append_movie.appendChild($col_card);
            }


        },
        fail:function(result){

        }
    });


    $("#btn-confirm-add-movie").on('click',function(){
        addMovieConfirm();
    });
});

function addMovieConfirm(){
    if(confirm("Add Movie?")){
        $("#click-add-movie").click();
    }else{
        return false;
    }
}

function movieDetail(pk){
    window.location.href = "<?php echo e(route('movieDetail', ['movie_pk' => "+ pk +"])); ?>";
}

</script>
